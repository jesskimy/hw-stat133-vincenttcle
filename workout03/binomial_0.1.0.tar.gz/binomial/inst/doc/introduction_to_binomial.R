## ---- echo = FALSE, message = FALSE--------------------------------------
knitr::opts_chunk$set(collapse = T, comment = "#>")
library(binomial)

## ------------------------------------------------------------------------
bin_choose(10, 2)

## ------------------------------------------------------------------------
bin_probability(success = 2, trials = 10, prob = 0.5)

## ------------------------------------------------------------------------
#probability of 1, 2, or 3 heads in 10 flips
bin_probability(success = 1:3, trials = 10, prob = 0.5)

## ------------------------------------------------------------------------
#distribution given 10 trials, with a 0.5 chance of success
bin_distribution(trials = 10, prob = 0.5)

## ------------------------------------------------------------------------
bindis_plot <- bin_distribution(trials = 10, prob = 0.5)
plot(bindis_plot)

## ------------------------------------------------------------------------
bin_cumulative(trials = 10, prob = 0.5)

## ---- fig.show='hold'----------------------------------------------------
bincum_plot <- bin_cumulative(trials = 10, prob = 0.5)
plot(bincum_plot)


## ------------------------------------------------------------------------
bin_variable(trials = 10, prob = 0.3)

## ------------------------------------------------------------------------
bin_var <- bin_variable(trials = 10, prob = 0.3)
summary(bin_var)

## ------------------------------------------------------------------------
#mean
bin_mean(trials = 10, prob = 0.3)

#variance
bin_variance(trials = 10, prob = 0.3)

#mode
bin_mode(trials = 10, prob = 0.3)

#skewness
bin_skewness(trials = 10, prob = 0.3)

#kurtosis
bin_kurtosis(trials = 10, prob = 0.3)


